﻿using System;

namespace FinanceUpW
{
    internal class MainForm
    {
        public MainForm()
        {
        }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}